from dateutil.rrule import DAILY, rrule, SA, SU, MO, TU, WE, TH, FR
from datetime import timedelta, date
import pandas as pd


def flatten_unique(series):
    all_topics = [x for x in series.tolist() if str(x) != 'nan']
    unique_topics = set([item.strip() if isinstance(item,str) else item for sublist in all_topics for item in sublist])
    return list(unique_topics)


def date_range(start_date, end_date):
    out = []
    for dt in rrule(DAILY, dtstart=start_date, until=end_date, byweekday=(SA,SU)):
        out.append(dt.date())
    return out


def next_dates(start_date, n):
    out = []
    for dt in rrule(DAILY, dtstart=start_date, until=start_date + timedelta(n*7), byweekday=(SA,SU)):
        out.append(dt.date())
    return out


def next_dates_weekend(start_date, n):
    out = []
    for dt in rrule(DAILY, dtstart=start_date, until=start_date + timedelta((1+n)*7/2), byweekday=(SA,SU)):
        out.append(dt.date())
    return out[:n]


def next_dates_weekday(start_date, n):
    out = []
    for dt in rrule(DAILY, dtstart=start_date, until=start_date + timedelta((1+n)*7/5), byweekday=(MO, TU, WE, TH, FR)):
        out.append(dt.date())
    return out[:n]


def this_weekend():
    out = []
    for dt in rrule(DAILY, dtstart=date.today(), until=date.today() + timedelta(7), byweekday=(SA,SU)):
        out.append(dt.date())
    return out


def last_weekend():
    out = []
    for dt in rrule(DAILY, dtstart=date.today() - timedelta(7), until=date.today(), byweekday=(SA,SU)):
        out.append(dt.date())
    return out


def read_sheet(xlsx, sheet_name):
    sheet = pd.DataFrame(xlsx[sheet_name].values)
    sheet = sheet.rename(columns=sheet.iloc[0])
    sheet = sheet.iloc[1:,sheet.iloc[0,:].notnull().tolist()]
    if "Date" in sheet.columns:
        sheet['Date'] = pd.to_datetime(sheet['Date']).dt.date
    return sheet


